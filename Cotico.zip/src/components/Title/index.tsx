import { TitleCotico} from './styles';


export function Title(){
    return(
            <TitleCotico source={require('../../assets/CoticoTBrancoSSombra.png')}/>
    );
}